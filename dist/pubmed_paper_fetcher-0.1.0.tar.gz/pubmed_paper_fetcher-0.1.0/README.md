\# PubMed Paper Fetcher



Fetch PubMed papers with non-academic authors using a command-line tool.



\## Usage



```bash

poetry run get-papers-list --query "covid vaccine" --file covid.csv --debug



